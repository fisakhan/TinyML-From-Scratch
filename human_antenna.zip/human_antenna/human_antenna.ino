// TinML From Scratch: Hands-On TinyML and Edge AI
// Chapter 03
// Asif Khan
void setup() {
  // Initialize serial communication at 115200 bits per second
  Serial.begin(115200);
}

void loop() {
  // Read the raw analog voltage from pin A0 (0 to 1023)
  int rawVoltage = analogRead(A0);
  
  // Print the raw numeric value
  Serial.print("Raw Number: ");
  Serial.print(rawVoltage);
  Serial.print("\t| ");
  
  // Create a quick visual wave using simple spaces and a dot
  int visualWidth = rawVoltage / 20; // Scale down for the screen
  for (int i = 0; i < visualWidth; i++) {
    Serial.print(" ");
  }
  Serial.println("*");
  
  // Wait 50 milliseconds before grabbing the next slice
  delay(50);
}
