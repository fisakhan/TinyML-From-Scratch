/*
TinyML From Scratch: Hands-On TinyML and Edge AI
https://github.com/fisakhan/TinyML-From-Scratch
*/

#include <Arduino.h>
#include <string.h>

// Include only one of the following two libraries, based on YOUR device
//#include <Arduino_BMI270_BMM150.h>// BLE Sense REV2
#include <Arduino_LSM9DS1.h>// BLE Sense LITE

// Replace this with YOUR exported project header
#include <shake_inferencing.h>

/*--------------------------------------------------------------------
  Feature buffer
--------------------------------------------------------------------*/
static float features[EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE];

/*--------------------------------------------------------------------
  Edge Impulse signal callback
--------------------------------------------------------------------*/
int raw_feature_get_data(size_t offset,
                         size_t length,
                         float *out_ptr)
{
    memcpy(out_ptr,
           features + offset,
           length * sizeof(float));

    return 0;
}

/*--------------------------------------------------------------------
  Setup
--------------------------------------------------------------------*/
void setup()
{
    Serial.begin(115200);
    while (!Serial);
    Serial.println();
    Serial.println("TinyML Real Sensor Inference");
    Serial.println("--------------------------------");

    /* Initialize IMU */
    if (!IMU.begin()) {
        Serial.println("ERROR: Failed to initialize IMU");

        while (1);
    }

    Serial.println("IMU initialized");
    Serial.print("Input frame size: ");
    Serial.println(EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE);
    Serial.print("Raw samples/frame: ");
    Serial.println(EI_CLASSIFIER_RAW_SAMPLES_PER_FRAME);
    Serial.print("Sampling interval (ms): ");
    Serial.println(EI_CLASSIFIER_INTERVAL_MS);
}

/*--------------------------------------------------------------------
  Main loop
--------------------------------------------------------------------*/
void loop()
{
    Serial.println();
    Serial.println("Collecting sensor data...");

    size_t ix = 0;

    /* Fill feature buffer */
    while (ix < EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE)
    {
        float ax, ay, az;
        float gx, gy, gz;
        // Serial.println(EI_CLASSIFIER_RAW_SAMPLES_PER_FRAME);

#if EI_CLASSIFIER_RAW_SAMPLES_PER_FRAME == 3

        /* Accelerometer only */
        if (IMU.accelerationAvailable())
        {
            //Serial.println("NOT accelerationAvailable...");
            Serial.println("accelerationAvailable...");
            IMU.readAcceleration(ax, ay, az);

            features[ix++] = ax;
            features[ix++] = ay;
            features[ix++] = az;

            delay(EI_CLASSIFIER_INTERVAL_MS);
        }
        //if (IMU.gyroscopeAvailable())
        //Serial.println("gyroAvailable...");

#elif EI_CLASSIFIER_RAW_SAMPLES_PER_FRAME == 6

        /* Accelerometer + gyroscope */
        if (IMU.accelerationAvailable() &&
            IMU.gyroscopeAvailable())
        {
            IMU.readAcceleration(ax, ay, az);
            IMU.readGyroscope(gx, gy, gz);

            features[ix++] = ax;
            features[ix++] = ay;
            features[ix++] = az;

            features[ix++] = gx;
            features[ix++] = gy;
            features[ix++] = gz;

            delay(EI_CLASSIFIER_INTERVAL_MS);
        }

#else
#error "Unsupported sensor configuration"
#endif
    }

    /* Create Edge Impulse signal */
    signal_t signal;
    signal.total_length =
        EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE;
    signal.get_data =
        &raw_feature_get_data;

    /* Result structure */
    ei_impulse_result_t result = { 0 };

    /* Run inference */
    EI_IMPULSE_ERROR res =
        run_classifier(&signal,
                       &result,
                       false);

    if (res != EI_IMPULSE_OK)
    {
        Serial.print("ERROR: ");

        Serial.println(res);

        return;
    }

    /* Print timing */

    Serial.println();
    Serial.println("Timing:");
    Serial.print("DSP: ");
    Serial.print(result.timing.dsp);
    Serial.println(" ms");
    Serial.print("Classification: ");
    Serial.print(result.timing.classification);
    Serial.println(" ms");

    /* Print predictions */
    Serial.println();
    Serial.println("Predictions:");

    for (size_t i = 0;
         i < EI_CLASSIFIER_LABEL_COUNT;
         i++)
    {
        Serial.print(result.classification[i].label);

        Serial.print(": ");

        Serial.println(result.classification[i].value,
                       4);
    }

#if EI_CLASSIFIER_HAS_ANOMALY == 1

    Serial.print("Anomaly score: ");
    Serial.println(result.anomaly, 4);

#endif

    delay(500);
}